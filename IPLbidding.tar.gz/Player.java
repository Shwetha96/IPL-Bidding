import java.util.*;
import java.io.*;
public class Player {
	
	   int i=0;
	   String playerName;
	   ArrayList<Integer> bidderId = new ArrayList<Integer>();
	   ArrayList<Integer> biddingPrice = new ArrayList<Integer>();
	   ArrayList<Bidder> bidderObjects = new ArrayList<Bidder>();
   	   int bidderCount=0,Bidders=0;
	   int c=1;
	   int count=1;
	
	    public Player(String playerName)
	   {
		   playerName=this.playerName;
		  
	   }
	   
	   public void attach( Bidder o )
	   {
			bidderObjects.add(o);
			
	   }
	  
	   
	   public void setBidderAndPrice(int bidderid, int biddingprice)
	   {
		  
		   bidderId.add(bidderid);
		   biddingPrice.add(biddingprice);
		   if(c==bidderCount)
		   {
			
			   notifyDeal();
		   }
		   else
		   {
			  
			   notifyBidding(bidderid,biddingprice);
		   }
		   c++;
	   }
	   
	   
	   public void completeDeal(int bidderId, int biddingPrice)
	   {
	   }
	  
	   private void notifyBidding(int bidderid,int biddingprice)
	   {
		               
		       
	        	if(count==1)
	        	{
	        		System.out.println("Bidding starts for player sachin");
		        	count++;
			        
	        	}
	        	      
	           	for(i=0;i<Bidders; i++)
	            	{
	           	
	           		     System.out.println(new Integer(bidderObjects.get(i).bidderId).toString()+" : ["+new Integer(bidderid).toString()+","+new Integer(biddingprice).toString()+"]");
	           		   
	           		}
	           		
	           	System.out.println();
	           
	   }
	   
	   private void notifyDeal()
	   {
		   int j=0,f=0;
		  
		   System.out.println("Bid Winner");
		   for(i=0;i<Bidders-1; i++)
		   {
			 
			   for(i=0;i<Bidders-1; i++)
	          	{
				   for(j=0; j<bidderCount; j++)
				   {
					   if(bidderObjects.get(i).bidderId==bidderId.get(j))
					   {
						   f=1;
						   break;
					   }
					   else
						   f=0; 
					   
				   }
						
				   j++;
				   
				   if(f==1)
				   {
					   System.out.println(new Integer(bidderObjects.get(i).bidderId).toString()+" : ["+new Integer((bidderObjects.get(i).Budget)-10).toString()+","+new Integer(bidderObjects.get(bidderCount).bidderId).toString()+"]");
					  
				   }
				   else
				   {
					   System.out.println(new Integer(bidderObjects.get(i).bidderId).toString()+" : ["+new Integer(bidderObjects.get(i).Budget).toString()+","+new Integer(bidderObjects.get(bidderCount).bidderId).toString()+"]");
					   
				   }
					   
				        
	          	}
         		
			   System.out.println(new Integer(bidderObjects.get(i).bidderId).toString()+" : ["+new Integer((bidderObjects.get(i).Budget)-biddingPrice.get(bidderCount-1)).toString()+","+new Integer(bidderObjects.get(bidderCount).bidderId).toString()+"]");
		     	
         	}
	         
	   }
	   
    
}
