
	public abstract class Observer {
	    protected Player player;
	    public abstract void updateBidding(int bidderId,int Budget);
	    public abstract void updateFinalDeal();
	}
	
	

