import java.util.ArrayList;


public class Bidder extends Observer {

	
	int bidderId,Budget;   
	Player p=new Player("");
	public Bidder(int bId,int budget)
	{
		bidderId=bId;
		Budget=budget;
	}
	@Override
	public void updateBidding(int bId,int budget) {
		// TODO Auto-generated method stub
		
		
		//p.notifyInitial(bId,budget);
		
	}

	@Override
	public void updateFinalDeal() {
		// TODO Auto-generated method stub
		//p.notifyFinal();
	}

}
