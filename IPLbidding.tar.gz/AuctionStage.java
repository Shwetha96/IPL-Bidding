import java.util.*;
import java.io.*;
public class AuctionStage {

	public static void main(String[] args) throws IOException  {
		
		Scanner sn= new Scanner(System.in);
		String str;
		int i;
		
		try
		{
			
			Player p=new Player("");
			
			
			if((str=sn.next())!=null)
				p= new Player(str);
			if((str=sn.next())!=null)
				p.Bidders=Integer.parseInt(str);
			
			
			for(i=1; i<=p.Bidders ; i++)
			{
			    
				if((str=sn.next())!=null)
				{
					String[] a=str.split(",");
			    	
			    	int bId=Integer.parseInt(a[0]);
			    	int budget=Integer.parseInt(a[1]);
			   
			    	Bidder b=new Bidder(bId, budget);
			    	p.attach(b);
			    	
				}
			  
			    	
			    	
			    
			}
			
			
			if((str=sn.next())!=null)
			    p.bidderCount=Integer.parseInt(str);
		
			for(i=1; i<=p.bidderCount ; i++)
			
			{
				
				if((str=sn.next())!=null)
				{
					   
				    	String[] a=str.split(",");
				    	int bid=Integer.parseInt(a[0]);
				    	int biddingPrice=Integer.parseInt(a[1]);
			    		
				    	p.setBidderAndPrice(bid, biddingPrice);
				    	
				    	
				}
				
			
		    }
	
			
         
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		}

}
